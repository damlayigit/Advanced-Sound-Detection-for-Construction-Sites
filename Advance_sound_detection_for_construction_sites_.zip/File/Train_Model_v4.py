# import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import wave
import joblib  # for saving the model
import os

# import functions
from playsound import playsound
from numpy.fft import fft, ifft
from sklearn.svm import SVC
from sklearn.metrics import precision_score, accuracy_score
from sklearn.model_selection import train_test_split

# color palette
GC = 0   # white
DW = -1  # blue
DC = 1   # red


# Generating Fingerprint
# Inputs: fourier transformed Signal fft, threshold
# Returns: peaks above threshold and its position'''
def fingerprint(fft, threshold=0.05):
    fft = np.abs(fft)  # transform into real number
    peaks = []
    position = []
    for i in range(1, len(fft)-1):
        if fft[i] > fft[i - 1] and fft[i] > fft[i + 1] and fft[i] > threshold:
            peaks.append(fft[i])
            position.append(i)
        if i > 100000:
            break
    return peaks, position


# Generates Fingerprint for a list of signals
# Input: list filled with fourier transformed signals
# Output: list filled with peaks and their positions
# Not used
def fingerprint_array(fft_array):

    peaks = []
    positions = []
    for fft in fft_array:
        peak, position = fingerprint(fft[:100000])
        peaks.append(peak)
        positions.append(position)

    return peaks, positions


# Calculates the average position and amplitude of peaks
def mean_fingerprint(fft):

    peak, position = fingerprint(fft[:100000])
    mean_peak = np.mean(peak)
    mean_position = np.mean(position)

    return mean_peak, mean_position


# Calculates the fourier-transform
def fourier_transform(wav_obj):

    n_samples = wav_obj.getnframes()
    signal_wave = wav_obj.readframes(n_samples)
    signal_array = np.frombuffer(signal_wave, dtype=np.int16)
    fourier = np.fft.fft(signal_array)
    magnitude = np.abs(fourier)

    return fourier / np.max(magnitude)


# Input: unknown sound wav_obj, sound recognition model
def sound_recognition(wav_obj, model):

    fft_result = fourier_transform(wav_obj)
    peak, position = mean_fingerprint(fft_result)
    X = [[peak, position]]  # getting the correct data type
    prediction = model.predict(X)
    if prediction == GC:
        print("Grinder is detected.")
    elif prediction == DW:
        print("Drill on Wood is detected.")
    elif prediction == DC:
        print("Drill on Concrete is detected.")
    else:
        print("Error!")

# Import Drill Concrete
fft_dc = []
'''for filename in filenames_DC:
    with wave.open(filename, 'rb') as wave_file:
        fft_result = fourier_transform(wave_file)
        fft_dc.append(fft_result)'''
wav_file_dir = './Drilling_Machine_Concrete'
files_in_dir = os.listdir(wav_file_dir)

for filename in files_in_dir:
    file_path = os.path.join(wav_file_dir, filename)

    with wave.open(file_path, 'rb') as wave_file:
        fft_result = fourier_transform(wave_file)
        fft_dc.append(fft_result)


# Import Drill Wood
fft_dw = []
'''for filename in filenames_DW:
    with (wave.open(filename, 'rb') as wave_file):
        fft_result = fourier_transform(wave_file)
        fft_dw.append(fft_result)'''
wav_file_dir = './Drilling_Machine_Wood'
files_in_dir = os.listdir(wav_file_dir)

for filename in files_in_dir:
    file_path = os.path.join(wav_file_dir, filename)

    with wave.open(file_path, 'rb') as wave_file:
        fft_result = fourier_transform(wave_file)
        fft_dw.append(fft_result)

# Import Grinder Concrete
fft_gc = []
'''for filename in filenames_GC:
    with (wave.open(filename, 'rb') as wave_file):
        fft_result = fourier_transform(wave_file)
        fft_gc.append(fft_result)'''
wav_file_dir = './Grinder_Concrete'
files_in_dir = os.listdir(wav_file_dir)

for filename in files_in_dir:
    file_path = os.path.join(wav_file_dir, filename)

    with wave.open(file_path, 'rb') as wave_file:
        fft_result = fourier_transform(wave_file)
        fft_gc.append(fft_result)

# Create data for the model
X = []
y = []

for fft in fft_dw:
    peak, position = mean_fingerprint(fft)
    X.append([peak, position])
    y.append(DW)

for fft in fft_dc:
    peak, position = mean_fingerprint(fft)
    X.append([peak, position])
    y.append(DC)

for fft in fft_gc:
    peak, position = mean_fingerprint(fft)
    X.append([peak, position])
    y.append(GC)

score_history = []

for _ in range(20):
    # Split data into training, testing
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)  # random_state=42

    # Create classifier machine model
    # svm_model = SVC(kernel='linear', probability=True)  # for binary classification
    classifier = SVC(kernel='linear', decision_function_shape='ovr')

    # train the model
    classifier.fit(X_train, y_train)

    # test the model
    y_pred = classifier.predict(X_test)
    score = accuracy_score(y_test, y_pred)
    score_history.append(score)

    print("The score is: ", score*100, "%")

mean_score = np.mean(np.array(score_history))

print(f"The average score is {mean_score}!")

# visualize how fingerprint works

# plot the signal after the fourier transform
file_name = 'Drilling_Machine_Wood/DW10.wav'
wav_obj = wave.open(file_name, 'rb')
n_samples = wav_obj.getnframes()
sample_freq = wav_obj.getframerate()
signal_wave = wav_obj.readframes(n_samples)
signal_array = np.frombuffer(signal_wave, dtype=np.int16)
times = np.linspace(0, n_samples / sample_freq, num=n_samples)
fourier = np.fft.fft(signal_array)
N = len(fourier)
n = np.arange(N)
T = N / sample_freq
freq = n / T
magnitude = np.abs(fourier)

plt.figure(figsize=(12, 6))
plt.subplot(121)

plt.stem(freq, np.abs(fourier), 'b', markerfmt=" ", basefmt="-b")
plt.xlabel('Freq (Hz)')
plt.ylabel('FFT Amplitude |X(freq)|')
plt.xlim(0, 20000)

plt.subplot(122)

# plotting of peaks over threshold
wav_obj = wave.open(file_name,'rb')
fourier = fourier_transform(wav_obj)
peak, position = fingerprint(fourier[:100000])
mean_peak, mean_position = mean_fingerprint(fourier[:100000])
position = np.array(position) / T
mean_position = np.array(mean_position) / T
# plt.stem(freq, peak, 'b', markerfmt=" ", basefmt="-b")
plt.scatter(mean_position, mean_peak, color='green')
plt.scatter(position, peak, color='red')
plt.xlim(0, 20000)
plt.ylim(-0.04, 1)
plt.show()


# visualize all fingerprints with decison boundary
X = np.array(X)

# Create a mesh to plot the decision boundary
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 1),
                     np.arange(y_min, y_max, 0.1))

# Predict the label for each point in the mesh
Z = classifier.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
# Plot the decision boundary and margins
plt.contourf(yy, xx, Z, alpha=0.8, cmap=plt.cm.coolwarm)

# Plot the fingerprints
x_max = np.max(X[:, 1])
plt.scatter(X[:, 1], X[:, 0], c=y, edgecolors='k', cmap=plt.cm.coolwarm)
plt.xlim(0, x_max)
plt.ylim(-0.04, 1)
plt.show()

# Save the model to file
joblib.dump(classifier, "classifier_4.joblib")

new_sound = wave.open('Drilling_Machine_Wood/DW8.wav', 'rb')
sound_recognition(new_sound, classifier)


