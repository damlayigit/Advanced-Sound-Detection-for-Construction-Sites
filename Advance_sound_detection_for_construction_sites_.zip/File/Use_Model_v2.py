import joblib
import numpy as np
import wave

from pydub import AudioSegment
from pydub.utils import make_chunks
from collections import Counter
from datetime import datetime
import librosa
import pandas as pd
import librosa.display
import os
import matplotlib.pyplot as plt
import cv2

GC = 0
DW = -1
DC = 1


# Generates Fingerprint
def fingerprint(fft, threshold=0.05):
    fft = np.abs(fft)
    peaks = []
    position = []
    for i in range(1, len(fft)-1):
        if fft[i] > fft[i - 1] and fft[i] > fft[i + 1] and fft[i] > threshold:
            peaks.append(fft[i])
            position.append(i)
    return peaks, position


# Calculates the average position and amplitude of peaks
def mean_fingerprint(fft):
    peak, position = fingerprint(fft[:100000])
    mean_peak = np.mean(peak)
    mean_position = np.mean(position)
    return mean_peak, mean_position


# Calculates the fourier-transform
def fourier_transform(wav_obj):

    n_samples = wav_obj.getnframes()
    signal_wave = wav_obj.readframes(n_samples)
    signal_array = np.frombuffer(signal_wave, dtype=np.int16)
    fourier = np.fft.fft(signal_array)
    magnitude = np.abs(fourier)

    return fourier / np.max(magnitude)


def sound_recognition(wav_obj, model):

    fft_result = fourier_transform(wav_obj)
    peak, position = mean_fingerprint(fft_result)
    X = [[peak, position]]
    prediction = model.predict(X)
    return prediction
    '''if prediction == GC:
        print("Grinder is detected.")
    elif prediction == DW:
        print("Drill on Wood is detected.")
    elif prediction == DC:
        print("Drill on Concrete is detected.")
    else:
        print("Error!")'''

def sound_recognition_long(name):
    audio = AudioSegment.from_file(name, "wav")
    chunk_length_ms = 5000
    chunks = make_chunks(audio, chunk_length_ms)
    predictions = []
    for chunk in chunks:
        wav_file = chunk.export(format="wav")
        wav_obj = wave.open(wav_file, 'rb')
        predictions.append(sound_recognition(wav_obj, classifier)[0])
    most_recognized_sound = max(set(predictions), key=predictions.count)
    if most_recognized_sound == GC:
        print("Grinder is detected.")
    elif most_recognized_sound == DW:
        print("Drill on Wood is detected.")
    elif most_recognized_sound == DC:
        print("Drill on Concrete is detected.")
    else:
        print("Error!")
    return most_recognized_sound

def identify_silent_periods(file_path):
    # Load the audio file
    y, sr = librosa.load(file_path, sr=None)

    # Normalize the audio signal
    y = librosa.util.normalize(y)

    
    # Trim silence from the beginning and end
    y, _ = librosa.effects.trim(y)
    y_real = y.copy()
    total_duration = librosa.get_duration(y=y, sr=sr)

    S = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=128, fmax=8000)
    S_dB = librosa.power_to_db(S, ref=np.max)

    # Display the spectrogram without the color bar
    plt.figure(figsize=(10, 4))
    librosa.display.specshow(S_dB, sr=sr, x_axis='time', y_axis='mel', fmax=8000)
    plt.tight_layout()
    plt.axis('off')
    #save the image 
    plt.savefig('temp.png')
    plt.close()
    #read the image
    img = cv2.imread('temp.png')
    # Convert to HSV color space
    
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # Define the red color range
    # Define the red color range
    lower_red1 = np.array([0, 50, 50])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 50, 50])
    upper_red2 = np.array([180, 255, 255])

    # Threshold the image to get only red regions
       # Threshold the image to get only red regions
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask = cv2.bitwise_or(mask1, mask2)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    total_width = img.shape[1]
    time_per_pixel = total_duration / total_width

    min_duration = 2  # Minimum duration in seconds
    min_width_in_pixels = min_duration / time_per_pixel
    red_regions = []
    duration = 0
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w > min_width_in_pixels:
            start_time = x * time_per_pixel
            end_time = (x + w) * time_per_pixel
            duration += end_time - start_time
            red_regions.append((start_time, end_time))

    print(f'The machine was used during {len(red_regions)} periods.')
    #visualize it
    result = img.copy()
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w > min_width_in_pixels:
            cv2.rectangle(result, (x, y), (x + w, y + h), (0, 255, 0), 2)

    plt.imshow(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
    plt.title('Detected Red Regions')
    plt.show()
    for i, (start_time, end_time) in enumerate(red_regions):
        start_sample = int(start_time * sr)
        end_sample = int(end_time * sr)
        segment = y_real[start_sample:end_sample]
        break
    return total_duration, len(red_regions), duration


def save_data(name, sound, duration, periods, time_used):
    # Read existing data from Excel into a DataFrame
    existing_data = pd.read_excel(name)

    if sound == GC:
        sound = "GC"
    elif sound == DW:
        sound = "DW"
    elif sound == DC:
        sound = "DC"
    else:
        sound = "Not recognized"

    # Get today's date
    today = datetime.now()

    # Format the date as a string that Excel can display
    excel_date_format = today.strftime("%Y-%m-%d %H:%M:%S")

    data = {
        'Date': [excel_date_format],
        'Detected Sound': [sound],
        'Duration': [duration],
        'Periods': [periods],
        'Total Time used': [time_used]
    }


    # Create a DataFrame
    df_new = pd.DataFrame(data)

    # Append new_data to existing_data
    updated_data = pd.concat([existing_data, df_new], ignore_index=True)

    # Save the DataFrame to an Excel file
    updated_data.to_excel(name, index=False)


def delete_data(name):
    data = {
        'Date': [],
        'Detected Sound': [],
        'Duration': [],
        'Periods': [],
        'Total Time used': []
    }

    # Create a DataFrame
    df_new = pd.DataFrame(data)

    # Save the DataFrame to an Excel file
    df_new.to_excel(name, index=False)

if __name__=='__main__':
    # open trained model
    classifier = joblib.load("classifier.joblib")

    # import unknown sound
    #file_name = ('GC_long/GC_long_5.wav')
    #sound = sound_recognition_long(file_name)
    #duration, periods, time_used = identify_silent_periods(file_name)

    filepath = r"C:\Users\CanCan\Documents\Sound Recordings\Recording.wav"
    sound = sound_recognition_long(filepath)
    duration, periods, time_used = identify_silent_periods(filepath)
    save_data("Output.xlsx", sound, duration, periods, time_used)
    #delete_data("Output.xlsx")


